import React from 'react'
import { useState } from 'react'
import './App.css';
import About from './component/About';
import Navbar from './component/Navbar';
import Textarea from './component/Textarea';
import Alert from './component/Alert';

function App() {
  const [colorID, setcolorID] = useState(false);
  const [mode, setmode] = useState('light');
  const [alert, setAlert] = useState(null);
  const handleDarkMode = (radioCheck) => {
    console.log(radioCheck)
    if (mode === 'light') {
      setmode('dark');
      document.body.style.backgroundColor = 'grey';
      showAlert("Dark mode is actived", "success");
    } if (mode === 'dark' && radioCheck == true) {
      setmode('light')
      document.body.style.backgroundColor = 'white';
      showAlert("Light mode is actived", "success");
    }
    if (mode === 'dark' && colorID == true) {
      setmode('dark')
      document.body.style.backgroundColor = 'grey';
      showAlert("Light mode is actived", "success");
      setcolorID(false)
    }
    if (mode === 'dark' && colorID == true && radioCheck == true) {
      setmode('light')
      document.body.style.backgroundColor = 'white';
      showAlert("Light mode is actived", "success");
      setcolorID(false)
    }
    // else {
    //   setmode('light')
    //   document.body.style.backgroundColor = 'white';
    //   showAlert("Light mode is actived", "success");
    // }
  }

  const handleButtonMode = (color) => {
    setmode('dark');
    document.body.style.backgroundColor = color;
    showAlert("Dark mode is actived", "success");
    setcolorID(true)
  };

  const showAlert = (message, type) => {
    setAlert({
      msg: message,
      type: type
    })
    setTimeout(() => {
      setAlert(null)
    }, 3000);
  }

  return (
    <>
      <Navbar title="Textutility" about='Disable' mode={mode} handleDarkMode={handleDarkMode} handleButtonMode={handleButtonMode} />
      <Alert alert={alert} />
      <Textarea showAlert={showAlert} title="Enter Your Text Here :" mode={mode} ></Textarea>
      <About />
    </>
  );
}

export default App;
